INSERT INTO users (username, email) VALUES ('testuser1', 'testuser1@example.com');
INSERT INTO users (username, email) VALUES ('testuser2', 'testuser2@example.com');
